#ifndef ANIMATION_CONTROL_H
#define ANIMATION_CONTROL_H
#include <QGraphicsItem>
#include <QGraphicsRectItem>
//#include "playerobject.h"

/*THIS will include things related to velocity.
Not controls */
class Animation_Control : public QGraphicsRectItem
{
public:
    Animation_Control();
};

#endif // ANIMATION_CONTROL_H
