#ifndef MYRECT
#define MYRECT
#include "bullet.h"

#include <QGraphicsItem>
#include <animation_control.h>

#include <QGraphicsPixmapItem>
#include <QGraphicsRectItem>
#include <QObject>
#include <QTimer>

class myRect : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    myRect(QTimer *);
    void keyPressEvent(QKeyEvent * event);
    bool returnSpacePressed();
    float giveAngle();
    float giveSpeedX();
    float giveSpeedY();
    int giveWidth();
    int giveHeight();
    int giveHealth();

    void setTipShip(); //new
    float giveTipY();
    float giveTipX();

public slots:
    void movement();

private:
    QTimer * player_timer;
    bool spacePressed;

    int player_health;
    int bulletCooldown;

    float angle;

    int width;
    int height;

    float speed;
    float speed_x;
    float speed_y;

    //new
    float shipFrontX;
    float shipFrontY;

};

#endif // PLAYEROBJECT_H
