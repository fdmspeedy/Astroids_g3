#include "animation_control.h"
#include "playerobject.h"

#include<QGraphicsScene>
#include<QKeyEvent>

#include<QDebug>

Animation_Control::Animation_Control()
{

}


