# Astroids_g3

CSCI 41 Group 3 Asteroids Project

-------------------------------------------------
| = - = - = D O C U M E N T A T I O N = - = - = |
-------------------------------------------------

How everything works will be pretty much typed in here.
Make sure to print this thingy before the one on one questions with Jamison.
Let me know if there are misconceptions and / or better explanations of how it works.

=========
|SOURCES|
=========

   - = main.cpp = -
   - = mainwindow.cpp = -
    
   - = scene.cpp = -
   - = station.cpp = -
   - = playership.cpp = -

=========
|HEADERS|
=========

   - = mainwindow.h = -
    
   - = scene.h = - 
   - = station.h = - 
   - = commandstationadd.h = -
   - = commandstationmove.h = -
   - = commandstationdelete.h = -
   - = playership.h = -

===========
|DISTFILES|
===========

   - = pixmap_station = -

===========
|CHANGELOG|
===========

10 / 30 / 2017
  - Just made it look nice and organized. No useful content just yet.
